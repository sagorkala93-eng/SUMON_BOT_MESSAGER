from flask import Flask, request
import requests

app = Flask(__name__)

PAGE_ACCESS_TOKEN = "YOUR_PAGE_ACCESS_TOKEN"
VERIFY_TOKEN = "YOUR_VERIFY_TOKEN"
GRAPH_URL = "https://graph.facebook.com/v17.0/me/messages"

def send_message(user_id, text):
    params = {"access_token": PAGE_ACCESS_TOKEN}
    data = {"recipient": {"id": user_id}, "message": {"text": text}}
    requests.post(GRAPH_URL, params=params, json=data)

@app.route("/", methods=["GET"])
def verify():
    if request.args.get("hub.mode") == "subscribe" and        request.args.get("hub.verify_token") == VERIFY_TOKEN:
        return request.args.get("hub.challenge")
    return "Invalid verification token", 403

@app.route("/", methods=["POST"])
def webhook():
    data = request.json
    if "entry" in data:
        for entry in data["entry"]:
            for message_event in entry["messaging"]:
                if "message" in message_event:
                    sender = message_event["sender"]["id"]
                    text = message_event["message"].get("text", "")
                    reply = f"তুমি বলেছো: {text}"
                    send_message(sender, reply)
    return "OK", 200

if __name__ == "__main__":
    app.run(port=5000, debug=True)
