# Messenger Bot (Python + Flask)

Simple Facebook Messenger Bot.

## Installation
pip install -r requirements.txt

## Run
python app.py

Use ngrok for webhook:
ngrok http 5000
